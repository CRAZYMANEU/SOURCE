# متطلبات التنصيب #
OWNER = ["CRAZ_UP", "CRAZ_UP"]
OWNER_NAME = "ᏨᎡᎯ ᏃᎽ"
BOT_TOKEN = "6875562036:AAHA02aA0LszliIr7RbkeLXGJmOeAS9klo4"
DATABASE = "mongodb+srv://Elkber:Elkber@cluster0.feuljpn.mongodb.net/?retryWrites=true&w=majority"
CHANNEL = "https://t.me/HLV_M"
GROUP = "https://t.me/ALTUNZAT"
VIDEO = "https://t.me/HLV_M/999"
LOGS = "SAGAL_botk"

